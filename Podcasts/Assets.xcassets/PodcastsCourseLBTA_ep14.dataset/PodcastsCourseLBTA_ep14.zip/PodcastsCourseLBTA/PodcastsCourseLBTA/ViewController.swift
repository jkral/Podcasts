//
//  ViewController.swift
//  PodcastsCourseLBTA
//
//  Created by Brian Voong on 2/13/18.
//  Copyright © 2018 Brian Voong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }


}

